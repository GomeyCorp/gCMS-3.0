<?php if(!class_exists('raintpl')){exit;}?><!--
 _____
/ ____|
| |  __  ___  _ __ ___   ___ _   _
| | |_ |/ _ \| '_ ` _ \ / _ \ | | |
| |__| | (_) | | | | | |  __/ |_| |
\______|\___/|_| |_| |_|\___|\__, |
                            __/ |
                           |___/
Gomey Corp. Hey skid, want a meme?
-->
<!DOCTYPE html>
<html>
<title>Gomey Corp.</title>
<head>
  <!-- Latest CSS and Google Fonts -->
  <link rel="stylesheet" href="/assets/style.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.blue_grey-light_blue.min.css" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
<center>
<img src="http://gomey.tk/assets/logo.png" id="Logo" /></br></br>
  <h1>Failing Ventures</h1></br></br>
  <form action="http://gomey.tk/forums/">
    <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
      Forums
    </button>
  </form></br>
  <form action="http://gomey.tk/boards/">
    <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
      Boards
    </button>
  </form></br>
  <button id="show-dialog" class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored show-modal">
    RIP
  </button> GomeyFM is not available on this browser ;'(
</div></br></br></br>

Powered by gCMS 3.0 - <b>Mobile Version</b> - Made by Gomey for Gomey

</body>
</html>
